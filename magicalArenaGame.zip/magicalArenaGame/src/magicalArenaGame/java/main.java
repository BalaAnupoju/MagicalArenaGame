package magicalArenaGame.java;

public class main {
    public static void main(String[] args) {
        // Create two players
        Player player1 = new Player(50, 5, 10);  // health 50, strength 5, attack 10
        Player player2 = new Player(100, 10, 5); // health 100, strength 10, attack 5

        // Create the arena with the two players
        Arena arena = new Arena(player1, player2);

        // Start the fight
        arena.startFight();
    }
}
