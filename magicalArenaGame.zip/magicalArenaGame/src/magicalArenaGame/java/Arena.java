package magicalArenaGame.java;
public class Arena {
    private Player player1;
    private Player player2;

    // Constructor to initialize the players
    public Arena(Player player1, Player player2) {
        this.player1 = player1;
        this.player2 = player2;
    }

    // Method to start the fight
    public void startFight() {
        // Determine which player attacks first based on health
        Player attacker = player1.getHealth() <= player2.getHealth() ? player1 : player2;
        Player defender = attacker == player1 ? player2 : player1;

        // Fight continues until one player's health reaches 0
        while (player1.isAlive() && player2.isAlive()) {
            attacker.attack(defender); // Attacker attacks defender

            // Swap roles after each turn
            Player temp = attacker;
            attacker = defender;
            defender = temp;
        }

        // Declare the winner
        if (player1.isAlive()) {
            System.out.println("Player 1 wins!");
        } else {
            System.out.println("Player 2 wins!");
        }
    }
}
