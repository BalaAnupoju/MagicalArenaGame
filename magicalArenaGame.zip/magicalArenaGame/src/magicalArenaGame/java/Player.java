package magicalArenaGame.java;

import java.util.Random;

public class Player {
    private int health;
    private int strength;
    private int attack;

    // Constructor to initialize the player
    public Player(int health, int strength, int attack) {
        this.health = health;
        this.strength = strength;
        this.attack = attack;
    }

    // Method to simulate the player's attack on another player
    public void attack(Player opponent) {
        Random rand = new Random();

        // Attacker rolls the dice
        int attackRoll = rand.nextInt(6) + 1; // 1 to 6
        // Defender rolls the dice
        int defenseRoll = rand.nextInt(6) + 1; // 1 to 6

        // Calculate attack and defense damage
        int attackDamage = this.attack * attackRoll;
        int defenseDamage = opponent.strength * defenseRoll;

        // Calculate net damage and apply it
        int netDamage = Math.max(attackDamage - defenseDamage, 0);
        opponent.reduceHealth(netDamage);
    }

    // Method to reduce health of the player
    public void reduceHealth(int damage) {
        this.health = Math.max(this.health - damage, 0);
    }

    // Check if the player is still alive
    public boolean isAlive() {
        return this.health > 0;
    }

    // Getter methods for attributes
    public int getHealth() {
        return health;
    }

    public int getAttack() {
        return attack;
    }

    public int getStrength() {
        return strength;
    }
}
