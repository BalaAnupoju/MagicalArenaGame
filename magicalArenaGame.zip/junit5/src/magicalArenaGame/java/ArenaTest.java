package magicalArenaGame.java;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.Test;

import magicalArenaGame.java.Arena;
import magicalArenaGame.java.Player;

public class ArenaTest {

    @Test
    public void testPlayerAttack() {
        // Create two players
        Player player1 = new Player(50, 5, 10);  // health 50, strength 5, attack 10
        Player player2 = new Player(100, 10, 5); // health 100, strength 10, attack 5

        // Player 1 attacks player 2
        player1.attack(player2);

        // Assert player 2's health has decreased
        assertTrue(player2.getHealth() < 100);
        assertTrue(player1.getHealth() == 50);
    }


	@Test
    public void testArenaFight() {
        Player player1 = new Player(50, 5, 10);
        Player player2 = new Player(100, 10, 5);

        Arena arena = new Arena(player1, player2);

        // Start the fight
        arena.startFight();

        // Assert that one player is dead and the other is alive
        assertFalse(player1.isAlive() || player2.isAlive());
    }
}
